import os,json,secrets,hmac,hashlib,threading
from pathlib import Path
from flask import Flask,request,session,send_from_directory,jsonify,abort
from werkzeug.middleware.proxy_fix import ProxyFix
ROOT=Path(__file__).parent; DATA=Path(os.environ.get('DATA_DIR',ROOT/'data')); DATA.mkdir(parents=True,exist_ok=True); MEDIA=DATA/'media'; MEDIA.mkdir(exist_ok=True)
CODE=os.environ['EDITOR_CODE']; assert len(CODE)>=12,'EDITOR_CODE minimum 12 characters'
app=Flask(__name__); app.secret_key=os.environ['SECRET_KEY']; app.config.update(MAX_CONTENT_LENGTH=250*1024*1024,SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Strict',SESSION_COOKIE_SECURE=os.getenv('HTTPS','1')=='1'); app.wsgi_app=ProxyFix(app.wsgi_app,x_proto=1); lock=threading.Lock(); original=json.loads((ROOT/'pages.json').read_text()); state=DATA/'book.json'
def load():
 raw=state.read_bytes() if state.exists() else b'[]'; return json.loads(raw),hashlib.sha256(raw).hexdigest()
def editor():
 if not session.get('editor'): abort(403)
def same_origin():
 if request.headers.get('Origin') != request.host_url.rstrip('/'): abort(403)
@app.get('/')
def index(): return send_from_directory(ROOT,'index.html')
@app.get('/book')
def book():
 changes,v=load(); pages=[dict(p,**{}) for p in original];
 for i,c in enumerate(changes): pages[i].update(c)
 r=jsonify(pages=pages,version=v,editor=bool(session.get('editor'))); r.headers['Cache-Control']='no-store'; return r
@app.post('/login')
def login():
 same_origin(); code=(request.get_json() or {}).get('code','');
 if not isinstance(code,str) or not hmac.compare_digest(code,CODE): abort(403,'Kod salah')
 session.clear(); session['editor']=True; return jsonify(ok=True)
@app.post('/logout')
def logout(): same_origin(); session.clear(); return jsonify(ok=True)
@app.put('/book')
def save():
 same_origin(); editor(); data=request.get_json(); rows=data['pages'];
 if len(rows)!=len(original): abort(400)
 clean=[]
 for p in rows:
  media=[]
  for m in p.get('media',[]):
   src=m['src']; name=src.removeprefix('/media/');
   if src!='/media/'+name or '/' in name or not (MEDIA/name).is_file(): abort(400)
   media.append(dict(src=src,type=str(m['type']),name=str(m['name']),caption=str(m.get('caption',m['name']))))
  clean.append(dict(title=str(p['title']),text=str(p['text']),useText=bool(p['useText']),media=media))
 with lock:
  _,v=load()
  if v!=data['version']: abort(409,'Editor lain telah menyimpan. Muat semula dahulu.')
  raw=json.dumps(clean,ensure_ascii=False).encode(); tmp=state.with_suffix('.tmp'); tmp.write_bytes(raw); tmp.replace(state)
 return jsonify(version=hashlib.sha256(raw).hexdigest())
@app.post('/upload')
def upload():
 same_origin(); editor(); f=request.files['file']; types={'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp','image/gif':'.gif','video/mp4':'.mp4','video/webm':'.webm'}; ext=types.get(f.mimetype)
 if not ext: abort(415,'Gunakan JPG, PNG, WebP, GIF, MP4 atau WebM')
 name=secrets.token_hex(20)+ext; f.save(MEDIA/name); return jsonify(src='/media/'+name,type=f.mimetype,name=f.filename)
@app.get('/media/<name>')
def media(name):
 r=send_from_directory(MEDIA,name,conditional=True); r.headers['X-Content-Type-Options']='nosniff'; return r
