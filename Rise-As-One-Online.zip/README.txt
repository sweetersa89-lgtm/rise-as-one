RISE AS ONE – Penerbitan dalam talian
1. Muat naik kandungan folder ini ke repositori GitHub (private disyorkan).
2. Cipta Web Service Python di Render, sambungkan repositori.
3. Build command: pip install -r requirements.txt
   Start command: gunicorn --workers 1 --threads 4 --bind 0.0.0.0:$PORT app:app
4. Environment variables: EDITOR_CODE (pilih kod rawak panjang >=12 aksara), SECRET_KEY (rahsia rawak panjang), DATA_DIR=/var/data, HTTPS=1.
5. Pasang persistent disk pada /var/data sebelum penerbitan. Pelan berbayar mungkin diperlukan. Tanpa disk, perubahan boleh hilang.
6. Deploy dan kongsi URL HTTPS yang diberikan Render. Pembaca tanpa kod; editor tekan Log masuk editor. Pilih halaman, muat naik MP4 H.264/AAC atau gambar, tekan Terbitkan perubahan. Pembaca muat semula halaman.
Untuk ujian lokal: HTTPS=0, editor code dan secret key ditetapkan, flask --app app run. Jangan guna kod lemah. Jangan kongsi kod secara umum. Data dan media adalah awam kepada pembaca; pastikan izin peserta. Had permintaan aplikasi 250 MB; hosting mungkin mempunyai had lebih rendah. Padam media membuang paparan sahaja, bukan fail pada disk. Sandarkan folder data. Tiada penyimpanan automatik atau login individu. Gunakan satu worker seperti di atas. Kod akses perlu ditukar jika bocor.
